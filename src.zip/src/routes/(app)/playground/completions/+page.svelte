<script>
	import Completions from '$lib/components/playground/Completions.svelte';
</script>

<Completions />
