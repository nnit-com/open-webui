<script>
	import Notes from '$lib/components/playground/Notes.svelte';
</script>

<Notes />
