<script>
	import KnowledgeBase from '$lib/components/workspace/Knowledge/KnowledgeBase.svelte';
</script>

<KnowledgeBase />
